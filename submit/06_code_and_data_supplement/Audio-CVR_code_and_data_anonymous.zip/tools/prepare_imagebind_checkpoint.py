from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


CONFIG = {
    "audio_drop_path": 0.1,
    "audio_embed_dim": 768,
    "audio_kernel_size": 16,
    "audio_num_blocks": 12,
    "audio_num_heads": 12,
    "audio_num_mel_bins": 128,
    "audio_stride": 10,
    "audio_target_len": 204,
    "depth_drop_path": 0.0,
    "depth_embed_dim": 384,
    "depth_kernel_size": 16,
    "depth_num_blocks": 12,
    "depth_num_heads": 8,
    "imu_drop_path": 0.7,
    "imu_embed_dim": 512,
    "imu_kernel_size": 8,
    "imu_num_blocks": 6,
    "imu_num_heads": 8,
    "kernel_size": [2, 14, 14],
    "out_embed_dim": 1024,
    "text_embed_dim": 1024,
    "text_num_blocks": 24,
    "text_num_heads": 16,
    "thermal_drop_path": 0.0,
    "thermal_embed_dim": 768,
    "thermal_kernel_size": 16,
    "thermal_num_blocks": 12,
    "thermal_num_heads": 12,
    "video_frames": 2,
    "vision_embed_dim": 1280,
    "vision_num_blocks": 32,
    "vision_num_heads": 16,
}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert the official ImageBind-Huge .pth checkpoint."
    )
    parser.add_argument("--input-pth", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--vendor-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "third_party"
        / "imagebind_5120b6bb",
    )
    args = parser.parse_args()

    import torch
    from safetensors.torch import save_file

    sys.path.insert(0, str(args.vendor_root.resolve()))
    from imagebind.models.imagebind_model import ImageBindModel

    state = torch.load(args.input_pth, map_location="cpu", weights_only=True)
    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]
    model = ImageBindModel(**CONFIG)
    model.load_state_dict(state, strict=True)
    tensors = {
        key: value.detach().cpu().contiguous()
        for key, value in model.state_dict().items()
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    save_file(tensors, str(args.output_dir / "model.safetensors"))
    (args.output_dir / "config.json").write_text(
        json.dumps(CONFIG, indent=2) + "\n", encoding="utf-8"
    )
    print(args.output_dir)


if __name__ == "__main__":
    main()
