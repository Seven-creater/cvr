# Review Package Test Status

Local cold-package gate, 2026-07-24:

```text
python verify_package.py
Result: OK

python -m unittest discover -s tests -v
Ran 175 tests
Result: OK

python -m py_compile <all app/tests/tools Python files>
35 files compiled
Result: OK

bash -n <all scripts/*.sh>
8 scripts checked
Result: OK

bash <script> --help
8 scripts checked
Result: OK
```

The tests cover source ingest and clipping, AVE and VGG-MonoAudio supplements,
automatic review/finalization, source/pair/inverse leakage, fixed-set
preservation, bidirectional augmentation, low-rank adapter initialization,
exact reference masking, atomic/resumable E5 and ImageBind caches, blind human
audit preparation and partial summarization, reference perturbations,
OmniEmbed audio-mode cache identities, per-query statistics, and final evidence
audits.

The outer submission bundle is also extracted into a fresh temporary directory
by `submit/verify_submission.py`; package verification, compilation, and the
same unit tests run from that extracted copy.
