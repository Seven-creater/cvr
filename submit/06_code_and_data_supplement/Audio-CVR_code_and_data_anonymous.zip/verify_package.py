from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import re
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def canonical_sample_id(row: dict) -> str:
    for key in ("sample_id", "proposal_id", "candidate_id", "record_id"):
        value = str(row.get(key) or "").strip()
        if value:
            return value
    raise AssertionError("record has no stable sample/proposal/candidate identifier")


def canonical_dataset(row: dict) -> str:
    explicit = str(row.get("dataset") or "").strip().lower()
    if explicit:
        return explicit
    evidence = " ".join(
        str(row.get(key) or "")
        for key in (
            "source_disjoint_group_id",
            "raw_source_id",
            "reference_video",
            "target_video",
            "benchmark_provenance_set",
        )
    ).lower()
    if "vgg_monoaudio" in evidence or "monoaudio" in evidence:
        return "vgg_monoaudio"
    if "ave_boundary" in evidence or "/ave_" in evidence or "\\ave_" in evidence:
        return "ave"
    if "existing_vggsound" in evidence or "vggsound" in evidence:
        return "vggsound"
    if "worldsense" in evidence:
        return "worldsense"
    if "avatar" in evidence:
        return "avatar"
    raise AssertionError(f"cannot infer dataset for {canonical_sample_id(row)}")


def sequence_hash(rows: list[dict]) -> str:
    values = [
        f"{canonical_sample_id(row)}\t{row.get('direction', 'forward')}"
        for row in rows
    ]
    return hashlib.sha256(("\n".join(values) + "\n").encode()).hexdigest()


def verify_records() -> None:
    manifest_path = ROOT / "data" / "record_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    loaded: dict[str, list[dict]] = {}
    for entry in manifest["files"]:
        path = ROOT / "data" / entry["file"]
        rows = load_jsonl(path)
        assert len(rows) == entry["record_count"], path
        assert sha256(path) == entry["anonymous_sha256"], path
        assert sequence_hash(rows) == entry["sample_direction_sequence_sha256"], path
        loaded[entry["file"]] = rows

    test_rows = loaded["test_main_1000_anonymous.jsonl"]
    assert len(test_rows) == 1000
    assert len({canonical_sample_id(row) for row in test_rows}) == 1000
    assert Counter(row["b_subtype"] for row in test_rows) == {
        "sound_event": 829,
        "music": 171,
    }
    assert Counter(canonical_dataset(row) for row in test_rows) == {
        "avatar": 510,
        "vggsound": 275,
        "ave": 196,
        "worldsense": 10,
        "vgg_monoaudio": 9,
    }

    forward_rows = loaded["train_non_speech_forward_65_anonymous.jsonl"]
    bidirectional_rows = loaded["train_bidirectional_89_anonymous.jsonl"]
    validation_rows = loaded["validation_28_anonymous.jsonl"]
    assert len(forward_rows) == 65
    assert len(validation_rows) == 28
    assert Counter(row.get("direction", "forward") for row in bidirectional_rows) == {
        "forward": 65,
        "inverse": 24,
    }
    assert manifest["frozen_test1000_sha256"] == (
        "70bd998c33bd4c2168ac18afb26ec6fbe928b234c61241f53412be387d52ec9e"
    )
    commitment_meta = manifest["original_record_commitments"]
    commitment_path = ROOT / "data" / commitment_meta["file"]
    commitments = load_jsonl(commitment_path)
    assert len(commitments) == commitment_meta["record_count"] == 1182
    assert sha256(commitment_path) == commitment_meta["sha256"]
    by_file = {
        name: path.read_bytes().splitlines()
        for name, path in (
            (entry["file"], ROOT / "data" / entry["file"])
            for entry in manifest["files"]
        )
    }
    for commitment in commitments:
        line = by_file[commitment["file"]][commitment["index"]]
        row = json.loads(line)
        assert canonical_sample_id(row) == commitment["stable_id"]
        assert hashlib.sha256(line).hexdigest() == commitment["anonymous_line_sha256"]


def verify_adapters() -> None:
    expected_seeds = {13, 23, 42, 71, 101}
    found: set[int] = set()
    for directory in (ROOT / "checkpoints").glob("seed_*"):
        seed = int(directory.name.split("_", 1)[1])
        config = json.loads(
            (directory / "adapter_config.json").read_text(encoding="utf-8")
        )
        assert (directory / "adapter.pt").stat().st_size > 0
        assert config["seed"] == seed
        assert config["adapter_architecture"] == "low_rank_residual"
        assert config["adapter_rank"] == 32
        assert config["trainable_parameter_count"] == 688131
        found.add(seed)
    assert found == expected_seeds


def verify_final_evidence() -> None:
    evidence = ROOT / "evidence" / "final"
    final_audit = json.loads(
        (evidence / "weak_accept_repair" / "final_audit.json").read_text(
            encoding="utf-8"
        )
    )
    assert final_audit["state"] == "PAPER_EVIDENCE_COMPLETE"
    assert final_audit["full1000_count"] == 1000
    assert final_audit["full1000_membership_unchanged"] is True
    assert final_audit["violation_count"] == 0

    human = json.loads(
        (
            evidence
            / "weak_accept_repair"
            / "human_audit_summary"
            / "human_audit_summary.json"
        ).read_text(encoding="utf-8")
    )
    assert human["partial_audit"] is True
    assert human["unique_sample_count"] == 50
    assert human["core150"]["valid_count"] + human["supplement50"]["valid_count"] == 34

    e5_audit = json.loads(
        (evidence / "e5_statistics" / "audit.json").read_text(encoding="utf-8")
    )
    assert e5_audit == {
        "seed_count": 5,
        "mode_count": 9,
        "eval_count": 1000,
        "gallery_count": 2000,
        "sample_ids_identical": True,
        "violation_count": 0,
        "violations": [],
    }

    imagebind = json.loads(
        (
            evidence / "imagebind_statistics" / "statistics_summary.json"
        ).read_text(encoding="utf-8")
    )
    assert imagebind["state"] == "COMPLETE"
    assert imagebind["selection_uses_test_metrics"] is False

    omniembed = json.loads(
        (
            evidence
            / "weak_accept_repair"
            / "omniembed_evaluation"
            / "evaluation_summary.json"
        ).read_text(encoding="utf-8")
    )
    assert omniembed["audiocvr_query_count"] == 1000
    assert omniembed["omnicvr_query_count"] == 1000
    assert omniembed["nan_or_inf_count"] == 0
    assert omniembed["masking_reuses_same_score_matrix"] is True

    valid_rows = load_jsonl(
        evidence
        / "weak_accept_repair"
        / "human_audit_summary"
        / "human_valid_samples.jsonl"
    )
    valid_ids = {canonical_sample_id(row) for row in valid_rows}
    assert len(valid_ids) == 34
    per_query = load_jsonl(
        evidence
        / "weak_accept_repair"
        / "statistics"
        / "e5"
        / "e5_reference_ladder_per_query.jsonl"
    )
    sensitivity = [
        row
        for row in per_query
        if row["condition"] == "exact"
        and row["mode"] == "V_A_T"
        and row["model"] == "adapter"
        and row["sample_id"] in valid_ids
    ]
    assert len(sensitivity) == 34 * 5
    with_r1 = sum(row["with_correct_at_1"] for row in sensitivity) / len(sensitivity)
    masked_r1 = sum(row["masked_correct_at_1"] for row in sensitivity) / len(
        sensitivity
    )
    assert round(with_r1 * 100, 1) == 17.1
    assert round(masked_r1 * 100, 1) == 93.5


def verify_anonymity() -> None:
    forbidden = re.compile(
        r"(wangqihao|10\.1\.4\.86|/data02/usr/|[A-Za-z]:\\Users\\)",
        re.IGNORECASE,
    )
    text_suffixes = {
        ".csv",
        ".json",
        ".jsonl",
        ".md",
        ".py",
        ".sh",
        ".txt",
        ".yaml",
        ".yml",
    }
    violations: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        if path.resolve() == Path(__file__).resolve():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if forbidden.search(text):
            violations.append(str(path.relative_to(ROOT)))
    assert not violations, f"identity-bearing paths remain: {violations}"


def verify_package_manifest() -> None:
    path = ROOT / "PACKAGE_MANIFEST.json"
    if not path.exists():
        return
    manifest = json.loads(path.read_text(encoding="utf-8"))
    assert manifest["frozen_test1000_sha256"] == (
        "70bd998c33bd4c2168ac18afb26ec6fbe928b234c61241f53412be387d52ec9e"
    )
    assert len(manifest["files"]) == manifest["file_count"]
    assert sum(item["bytes"] for item in manifest["files"]) == manifest["total_bytes"]
    for item in manifest["files"]:
        item_path = ROOT / item["path"]
        assert item_path.is_file(), item["path"]
        assert item_path.stat().st_size == item["bytes"], item["path"]
        assert sha256(item_path) == item["sha256"], item["path"]


def verify_source_closure() -> None:
    required = [
        "app/audio_matters_natural.py",
        "third_party/imagebind_5120b6bb/LICENSE",
        "third_party/imagebind_5120b6bb/UPSTREAM.md",
        "third_party/imagebind_5120b6bb/imagebind/models/imagebind_model.py",
        "third_party/imagebind_5120b6bb/bpe/bpe_simple_vocab_16e6.txt.gz",
    ]
    for relative in required:
        assert (ROOT / relative).is_file(), relative

    modules = [
        "app.audio_cvr_external_baseline",
        "app.audio_cvr_paper_experiment",
        "app.audio_lines_single_source",
        "app.audio_matters_natural",
        "app.e5_audio_delta_train",
    ]
    for module in modules:
        importlib.import_module(module)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skip-imports",
        action="store_true",
        help="Only verify files and records; skip Python module imports.",
    )
    args = parser.parse_args()
    verify_records()
    verify_adapters()
    verify_final_evidence()
    verify_anonymity()
    verify_package_manifest()
    if not args.skip_imports:
        verify_source_closure()
    print("Audio-CVR anonymous review package: OK")


if __name__ == "__main__":
    main()
