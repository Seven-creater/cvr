# Audio-CVR Review Data Card

## Scope

Audio-CVR is a controlled, non-speech diagnostic benchmark for directional
audio changes under largely preserved visual context. The unchanged reference
is retained as a query-specific pre-edit negative.

The frozen main test contains 1,000 records:

| Field | Count |
|---|---:|
| sound event | 829 |
| music | 171 |
| Avatar-derived | 510 |
| VGGSound | 275 |
| AVE | 196 |
| WorldSense | 10 |
| VGG-MonoAudio supplement | 9 |

The review package also contains 65 forward training records, 24 accepted
inverse records (89 directional instances in total), and 28 validation records.

## What is distributed

The files under `data/` contain the complete derived annotations and split
records used by the experiments. They include stable IDs, edit text,
reference/target media paths relative to a local media root, subtype and source
metadata, model-review decisions, and hard-negative metadata.

The path-anonymization transform changes only identity-bearing local roots. It
does not change membership, order, IDs, labels, verifier outputs, or numerical
fields. The manifest records:

1. the SHA256 of each exact frozen pre-anonymization JSONL;
2. the SHA256 of each path-anonymized review copy;
3. the stable ID and direction sequence hash;
4. a line-level SHA256 commitment for every original and review-copy record.

## What is not distributed

Raw videos are not included. They originate from third-party datasets and must
be obtained under the corresponding upstream terms. The package does not grant
rights to redistribute those videos. Model backbone weights are also omitted
and remain governed by their model licenses.

The VGG-MonoAudio records are retained as a separately identifiable controlled
supplement in provenance; they are not presented as independent natural-source
videos.

## Construction and quality evidence

The archive includes automatic review decisions, repeat-review summaries,
deduplication and leakage audits, reference perturbation audits, and a blinded
single-rater partial human audit. The human audit covers 50 unique records:
34 were marked overall valid. It is explicitly a partial audit, not a
multi-rater gold-standard validation.

The benchmark should therefore be described as:

> automatically curated and model-verified, with a partial blinded single-rater
> human audit.

It should not be described as fully human validated.

## Frozen identity

The exact original Test1000 SHA256 is:

```text
70bd998c33bd4c2168ac18afb26ec6fbe928b234c61241f53412be387d52ec9e
```

The review-copy hash differs only because local path roots were anonymized.
Both hashes and the deterministic record commitments are in
`data/record_manifest.json`.

