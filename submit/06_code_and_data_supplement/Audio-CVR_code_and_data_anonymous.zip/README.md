# Audio-CVR Anonymous Code and Data Supplement

This archive is the self-contained review package for the Audio-CVR paper. It
contains the frozen benchmark annotations, training and validation annotations,
five reported adapter checkpoints, curation and evaluation source code, focused
tests, and the per-query evidence used to build the reported tables.

No external repository is required to inspect the data or verify the reported
statistics. Raw videos and third-party backbone weights are not redistributed;
they remain subject to their upstream licenses.

## Review package map

- `data/`: path-anonymized Test1000, train65, bidirectional train89, val28,
  record manifest, and line-level commitments to the exact frozen records.
- `checkpoints/`: five low-rank E5 adapter checkpoints for seeds
  `13, 23, 42, 71, 101`.
- `evidence/final/`: final dataset audits, E5/ImageBind/OmniEmbed per-query
  results, 20,000-draw paired statistics, reference perturbation results, and
  the partial blinded human audit.
- `app/`: curation, split, embedding, reference masking, perturbation, human
  audit, and statistical evaluation code.
- `scripts/`: detached/resumable launchers used for the reported server runs.
- `third_party/imagebind_5120b6bb/`: pinned ImageBind inference source and its
  upstream license.
- `tests/`: deterministic unit and integration tests.
- `verify_package.py`: one-command record, checkpoint, evidence, anonymity, and
  import-closure audit.

## Fast integrity check

From the extracted archive:

```bash
python verify_package.py --skip-imports
```

After installing dependencies:

```bash
python -m pip install -r requirements-review.txt
python verify_package.py
python -m unittest discover -s tests -v
```

The package verifier checks the frozen Test1000 commitment
`70bd998c33bd4c2168ac18afb26ec6fbe928b234c61241f53412be387d52ec9e`,
all path-anonymized file hashes, stable record ordering, subtype/source
distributions, five adapter configurations, the 34/50 human-valid sensitivity
analysis, final model audits, and identity-bearing paths.

## Data availability boundary

The derived annotations and all review-time evidence are included now. The
archive intentionally omits raw videos because the source media come from
third-party datasets and remain governed by their original terms. To reconstruct
media locally, obtain the corresponding upstream datasets, retain their folder
names, and point `AUDIO_CVR_DATA_ROOT` or the relevant `--media-root` arguments
to that location. See `DATA_CARD.md`.

The path-anonymized JSONL files preserve record membership, order, IDs, edit
text, reference/target paths relative to a media root, verifier decisions,
hard-negative metadata, provenance, and split fields. `data/record_manifest.json`
records both the exact pre-anonymization SHA256 and the review-copy SHA256.
`data/original_record_commitments.jsonl` commits to every original line without
exposing an identity-bearing local path.

## Backbone setup

The reported models use third-party checkpoints that are too large for the
submission archive:

- E5-Omni: `Haon-Chen/e5-omni-7B`.
- ImageBind-Huge: official `imagebind_huge.pth`; convert it with
  `tools/prepare_imagebind_checkpoint.py`.
- OmniEmbed-MultiVENT: Qwen2.5-Omni base plus
  `Tevatron/OmniEmbed-v0.1-multivent`.

Set local paths explicitly in the launchers. No test metric is used to select a
benchmark member, prompt, fusion weight, model checkpoint, or hyperparameter.
See `REPRODUCTION.md` for smoke tests and full-run entry points.

## Platform notes

The full experiments used Linux, CUDA-capable GPUs, Python, FFmpeg/ffprobe, and
PyAV. Data-only and statistical integrity checks are CPU-only. The launchers
support atomic item caches and resume; `--expected-head SKIP` is available only
for running this anonymous archive outside a Git checkout.

