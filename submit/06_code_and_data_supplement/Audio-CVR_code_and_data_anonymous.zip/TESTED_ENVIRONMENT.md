# Tested Environment

The final runs used Ubuntu 20.04 (Linux 5.15), Python 3.10.20, FFmpeg/ffprobe
4.2.7, eight NVIDIA RTX A6000 GPUs, NVIDIA driver 535.104.05, and CUDA 12.2.

## E5, ImageBind, data, and statistics environment

```text
numpy=1.24.4
torch=2.10.0
torchaudio=2.10.0
torchvision=0.25.0
av=17.0.0
soundfile=0.13.1
Pillow=12.2.0
scipy=1.15.3
sentence-transformers=5.4.1
transformers=5.8.0
huggingface-hub=1.14.0
safetensors=0.7.0
accelerate=1.12.0
einops=0.8.2
ftfy=6.3.1
regex=2026.4.4
timm=0.4.5
imageio=2.37.3
```

## OmniEmbed-MultiVENT environment

```text
numpy=1.26.4
torch=2.3.0
torchaudio=2.3.0
torchvision=0.18.0
av=16.0.1
soundfile=0.13.1
Pillow=10.4.0
scipy=1.15.3
transformers=4.57.1
huggingface-hub=0.35.3
safetensors=0.5.3
accelerate=1.11.0
peft=0.17.1
einops=0.8.1
regex=2025.10.23
librosa=0.11.0
```

The Qwen Omni media utility was supplied through the launcher's explicit
`--qwen-omni-utils-root` option. The package supports separate Python
executables for the E5/ImageBind and OmniEmbed stages because their tested
Transformers/PyTorch stacks differ.

The version lists document the successful environment; they are not intended
to force an incompatible CUDA wheel onto another machine. Install a
platform-compatible PyTorch build first, then the packages in
`requirements-review.txt`.

