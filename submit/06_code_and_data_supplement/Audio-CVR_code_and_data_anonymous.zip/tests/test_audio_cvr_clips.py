from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app.audio_cvr_clips import build_audio_cvr_clips
from app.composed_data import ensure_layout


class AudioCvrClipsTests(unittest.TestCase):
    def test_clip_outputs_are_journaled_once_and_reused(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            source = root / "raw" / "daily_omni" / "video" / "source.mp4"
            source.parent.mkdir(parents=True)
            source.write_bytes(b"video")

            def fake_extract(*, output_path: Path, **_: object) -> None:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                output_path.write_bytes(b"clip")

            media = {"has_video": True, "has_audio": True, "duration_seconds": 20.0}
            with mock.patch("app.audio_cvr_clips.probe_media", return_value=media), mock.patch(
                "app.audio_cvr_clips._extract_clip_atomic", side_effect=fake_extract
            ):
                first = build_audio_cvr_clips(
                    root=root,
                    datasets=["daily_omni"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                )
                resumed = build_audio_cvr_clips(
                    root=root,
                    datasets=["daily_omni"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                )

            progress_path = Path(first["progress_path"])
            progress_rows = [line for line in progress_path.read_text(encoding="utf-8").splitlines() if line.strip()]
            self.assertEqual(2, first["durable_clip_count"])
            self.assertEqual(2, resumed["durable_clip_count"])
            self.assertEqual(2, len(progress_rows))

    def test_builds_default_10s_clips_and_skips_sources_with_too_few_segments(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw" / "daily_omni"
            raw.mkdir(parents=True)
            long_video = raw / "long.mp4"
            short_video = raw / "short.mp4"
            long_video.write_bytes(b"video")
            short_video.write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {
                    "has_video": True,
                    "has_audio": True,
                    "duration_seconds": 30.0 if Path(path).name == "long.mp4" else 15.0,
                }

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    datasets=["daily_omni"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                    dry_run=True,
                )

            self.assertEqual(1, summary["source_video_count"])
            self.assertEqual(3, summary["segment_count"])
            self.assertEqual({"daily_omni": 1}, summary["source_counts"])
            self.assertEqual({"too_few_segments:1": 1}, summary["skipped_counts"])
            self.assertEqual({"too_few_segments:1": 1}, summary["skipped_counts_by_dataset"]["daily_omni"])

            records = [
                json.loads(line)
                for line in Path(summary["manifest_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            self.assertEqual([10.0, 10.0, 10.0], [record["duration_seconds"] for record in records])
            self.assertTrue(records[0]["output_path"].startswith("clips/audio_cvr_8_12s/daily_omni_long_"))

    def test_rejects_clip_seconds_outside_8_12_window(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            with self.assertRaises(ValueError):
                build_audio_cvr_clips(root=root, clip_seconds=6, min_clip_seconds=8, max_clip_seconds=12, dry_run=True)

    def test_scans_known_server_dataset_layouts_instead_of_only_video_dirs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw"
            video_paths = [
                raw / "daily_omni" / "video" / "daily.mp4",
                raw / "hdtf" / "videos" / "hdtf_video.mp4",
                raw / "hdtf" / "clips" / "hdtf_clip.mp4",
                raw / "avatar" / "avatar_root.mp4",
                raw / "avatar" / "video" / "avatar_video.mp4",
                raw / "vggsound" / "scratch" / "class_a" / "vgg.mp4",
                raw / "vgg_monoaudio" / "inter_class" / "mixed" / "mono.mp4",
                raw / "worldsense" / "videos" / "world.mp4",
                raw / "VoxCeleb" / "vox.mp4",
            ]
            ignored_paths = [
                raw / "daily_omni" / "other" / "ignored.mp4",
                raw / "vgg_monoaudio" / "intra_class" / "ignored.mp4",
            ]
            for path in video_paths + ignored_paths:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 20.0}

            datasets = ["daily_omni", "hdtf", "avatar", "vggsound", "vgg_monoaudio", "worldsense", "VoxCeleb"]
            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    datasets=datasets,
                    exclude_datasets=["VoxCeleb"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                    dry_run=True,
                )

            self.assertEqual(
                {
                    "daily_omni": 1,
                    "hdtf": 2,
                    "avatar": 2,
                    "vggsound": 1,
                    "vgg_monoaudio": 1,
                    "worldsense": 1,
                },
                summary["discovered_video_counts"],
            )
            self.assertNotIn("VoxCeleb", summary["dataset_names"])
            self.assertEqual(8, summary["source_video_count"])
            self.assertEqual(16, summary["segment_count"])
            self.assertTrue(any(path.endswith("raw/vggsound/scratch") for path in summary["dataset_scan_roots"]["vggsound"]))
            self.assertTrue(any(path.endswith("raw/vgg_monoaudio/inter_class/mixed") for path in summary["dataset_scan_roots"]["vgg_monoaudio"]))

    def test_reports_avatar_single_clip_sources_as_too_few_segments(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw" / "avatar"
            raw.mkdir(parents=True)
            for index in range(3):
                (raw / f"avatar_{index}.mp4").write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 10.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    datasets=["avatar"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                    min_clips_per_source=2,
                    dry_run=True,
                )

            self.assertEqual({"avatar": 3}, summary["discovered_video_counts"])
            self.assertEqual(0, summary["source_video_count"])
            self.assertEqual({"too_few_segments:1": 3}, summary["skipped_counts_by_dataset"]["avatar"])

    def test_6_9_tail_segments_make_10s_sources_pairable(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw" / "avatar"
            raw.mkdir(parents=True)
            source = raw / "avatar.mp4"
            source.write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 10.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    output_root=root / "clips" / "audio_cvr_6_9s",
                    datasets=["avatar"],
                    clip_seconds=8,
                    min_clip_seconds=6,
                    max_clip_seconds=9,
                    min_clips_per_source=2,
                    include_tail_segment=True,
                    dry_run=True,
                )

            records = [
                json.loads(line)
                for line in Path(summary["manifest_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            self.assertEqual(1, summary["source_video_count"])
            self.assertEqual(2, summary["segment_count"])
            self.assertEqual([0.0, 2.0], [record["start_seconds"] for record in records])
            self.assertEqual([8.0, 10.0], [record["end_seconds"] for record in records])
            self.assertTrue(summary["include_tail_segment"])
            self.assertTrue(summary["manifest_path"].endswith("audio_cvr_6_9s_clips.jsonl"))

    def test_dataset_video_root_override_excludes_hdtf_short_clip_dir(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw" / "hdtf"
            video = raw / "videos" / "long.mp4"
            short_clip = raw / "clips" / "short.mp4"
            video.parent.mkdir(parents=True)
            short_clip.parent.mkdir(parents=True)
            video.write_bytes(b"video")
            short_clip.write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 30.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    datasets=["hdtf"],
                    dataset_video_roots={"hdtf": ("videos",)},
                    clip_seconds=8,
                    min_clip_seconds=6,
                    max_clip_seconds=9,
                    include_tail_segment=True,
                    dry_run=True,
                )

            self.assertEqual({"hdtf": 1}, summary["discovered_video_counts"])
            self.assertEqual(1, summary["source_video_count"])
            self.assertEqual(4, summary["segment_count"])
            self.assertTrue(all(path.endswith("raw/hdtf/videos") for path in summary["dataset_scan_roots"]["hdtf"]))

    def test_voxceleb_short_mp4s_are_grouped_by_parent_folder(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            video_dir = root / "raw" / "voxceleb" / "vox2_mp4" / "dev" / "id00001" / "youtube_a"
            ignored_dir = root / "raw" / "voxceleb" / "vox2_aac" / "dev" / "id00001" / "youtube_a"
            video_dir.mkdir(parents=True)
            ignored_dir.mkdir(parents=True)
            for name in ("00001.mp4", "00002.mp4"):
                (video_dir / name).write_bytes(b"video")
            (ignored_dir / "ignored.mp4").write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 7.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    output_root=root / "clips" / "audio_cvr_6_9s",
                    datasets=["voxceleb"],
                    clip_seconds=8,
                    min_clip_seconds=6,
                    max_clip_seconds=9,
                    min_clips_per_source=2,
                    include_tail_segment=True,
                    short_clip_group_datasets={"voxceleb"},
                    dry_run=True,
                )

            records = [
                json.loads(line)
                for line in Path(summary["manifest_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            groups = [
                json.loads(line)
                for line in Path(summary["groups_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            self.assertEqual({"voxceleb": 2}, summary["discovered_video_counts"])
            self.assertEqual(1, summary["source_video_count"])
            self.assertEqual(2, summary["segment_count"])
            self.assertEqual(1, len(groups))
            self.assertEqual(2, len(groups[0]["candidate_clip_ids"]))
            self.assertEqual(1, len({record["group_id"] for record in records}))
            self.assertTrue(summary["dataset_scan_roots"]["voxceleb"][0].endswith("raw/voxceleb/vox2_mp4/dev"))
            self.assertIn("voxceleb", summary["short_clip_group_datasets"])

    def test_voxceleb_singleton_parent_folder_is_not_manifested(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            video_dir = root / "raw" / "voxceleb" / "vox2_mp4" / "dev" / "id00001" / "youtube_a"
            video_dir.mkdir(parents=True)
            (video_dir / "00001.mp4").write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 7.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe):
                summary = build_audio_cvr_clips(
                    root=root,
                    output_root=root / "clips" / "audio_cvr_6_9s",
                    datasets=["voxceleb"],
                    clip_seconds=8,
                    min_clip_seconds=6,
                    max_clip_seconds=9,
                    min_clips_per_source=2,
                    include_tail_segment=True,
                    short_clip_group_datasets={"voxceleb"},
                    dry_run=True,
                )

            self.assertEqual(0, summary["source_video_count"])
            self.assertEqual(0, summary["segment_count"])
            self.assertEqual({"too_few_grouped_short_clips:1": 1}, summary["skipped_counts_by_dataset"]["voxceleb"])
            self.assertEqual("", Path(summary["manifest_path"]).read_text(encoding="utf-8"))
            self.assertEqual("", Path(summary["groups_path"]).read_text(encoding="utf-8"))

    def test_full_short_mp4_materialization_avoids_ffmpeg_reencode(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            video_dir = root / "raw" / "voxceleb" / "vox2_mp4" / "dev" / "id00001" / "youtube_a"
            video_dir.mkdir(parents=True)
            (video_dir / "00001.mp4").write_bytes(b"video one")
            (video_dir / "00002.mp4").write_bytes(b"video two")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 7.0}

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe), mock.patch(
                "app.audio_cvr_clips.subprocess.run", side_effect=AssertionError("ffmpeg should not run")
            ):
                summary = build_audio_cvr_clips(
                    root=root,
                    output_root=root / "clips" / "audio_cvr_6_9s",
                    datasets=["voxceleb"],
                    clip_seconds=8,
                    min_clip_seconds=6,
                    max_clip_seconds=9,
                    min_clips_per_source=2,
                    include_tail_segment=True,
                    short_clip_group_datasets={"voxceleb"},
                )

            records = [
                json.loads(line)
                for line in Path(summary["manifest_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            output_paths = [root / record["output_path"] for record in records]
            self.assertEqual([b"video one", b"video two"], [path.read_bytes() for path in output_paths])
            self.assertFalse(list(output_paths[0].parent.glob("*.tmp.*.mp4")))

    def test_clip_extraction_writes_temp_file_then_final_output(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ensure_layout(root)
            raw = root / "raw" / "daily_omni" / "video"
            raw.mkdir(parents=True)
            source = raw / "daily.mp4"
            source.write_bytes(b"video")

            def fake_probe(path: Path) -> dict:
                return {"has_video": True, "has_audio": True, "duration_seconds": 20.0}

            def fake_run(command: list[str], check: bool) -> None:
                self.assertTrue(check)
                Path(command[-1]).write_bytes(b"complete clip")

            with mock.patch("app.audio_cvr_clips.probe_media", side_effect=fake_probe), mock.patch(
                "app.audio_cvr_clips.subprocess.run", side_effect=fake_run
            ):
                summary = build_audio_cvr_clips(
                    root=root,
                    datasets=["daily_omni"],
                    clip_seconds=10,
                    min_clip_seconds=8,
                    max_clip_seconds=12,
                )

            records = [
                json.loads(line)
                for line in Path(summary["manifest_path"]).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            output_paths = [root / record["output_path"] for record in records]
            self.assertEqual(2, len(output_paths))
            self.assertTrue(all(path.read_bytes() == b"complete clip" for path in output_paths))
            self.assertFalse(list(output_paths[0].parent.glob("*.tmp.*.mp4")))


if __name__ == "__main__":
    unittest.main()
