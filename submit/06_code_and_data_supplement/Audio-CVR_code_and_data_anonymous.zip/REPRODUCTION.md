# Reproduction Guide

## 1. CPU-only package audit

```bash
python verify_package.py --skip-imports
```

This verifies the supplied data, checkpoints, per-query evidence, statistical
summaries, human-audit sensitivity result, and anonymity constraints without
loading a backbone.

## 2. Python environment and tests

Use Python 3.10 or 3.11, FFmpeg/ffprobe, and a CUDA-compatible PyTorch build for
model inference.

```bash
python -m pip install -r requirements-review.txt
python verify_package.py
python -m unittest discover -s tests -v
```

The package is not tied to the original server filesystem. Supply models and
media through command-line options or:

```bash
export AUDIO_CVR_DATA_ROOT=/absolute/path/to/reconstructed/media
```

## 3. Backbone preparation

### E5-Omni

Obtain `Haon-Chen/e5-omni-7B` and pass its directory through `--e5-model` or
`--e5-model-path`.

### ImageBind-Huge

Obtain the official ImageBind-Huge `.pth` checkpoint and convert it to the
format used by the packaged runtime:

```bash
python tools/prepare_imagebind_checkpoint.py \
  --input-pth /path/to/imagebind_huge.pth \
  --output-dir /path/to/imagebind_huge_converted
```

The pinned inference source and upstream license are under
`third_party/imagebind_5120b6bb/`.

### OmniEmbed-MultiVENT

Obtain a compatible Qwen2.5-Omni base model and
`Tevatron/OmniEmbed-v0.1-multivent`, then provide both paths to
`app.audio_cvr_omniembed`.

The reported E5/ImageBind and OmniEmbed runs used separate environments because
their tested Transformers/PyTorch versions differ. The exact successful
versions are recorded in `TESTED_ENVIRONMENT.md`. Do not combine the two model
stacks merely to run the CPU-only package audit and tests.

## 4. Command discovery and smoke tests

Each Python entry point exposes its exact arguments:

```bash
python -m app.audio_cvr_paper_experiment --help
python -m app.audio_cvr_external_baseline --help
python -m app.audio_cvr_weak_accept --help
python -m app.audio_cvr_omniembed --help
python -m app.e5_audio_delta_train --help
```

The tests use deterministic mock encoders for execution-path checks; they do
not download multi-billion-parameter models.

## 5. Principal full-run launchers

- `scripts/run_audio_cvr_avatar_like_test1000_4gpu.sh`: source ingest, clipping,
  staged proposal/review, and resumable high-volume construction.
- `scripts/run_audio_cvr_ave_boundary_fill_8gpu.sh`: AVE boundary-pair
  supplement.
- `scripts/run_audio_cvr_vgg_monoaudio_fill.sh`: controlled VGG-MonoAudio
  supplement.
- `scripts/run_audio_cvr_fixed_test1000_fill.sh`: fixed-set preservation,
  historical-candidate review, deduplication, and freeze.
- `scripts/run_audio_cvr_fewshot_bidir_final.sh`: few-shot adapter workflow.
- `scripts/run_audio_cvr_e5_imagebind_final_8gpu.sh`: final E5 and ImageBind
  caching/evaluation workflow.
- `scripts/run_audio_cvr_weak_accept_repair_8gpu.sh`: blinded audit,
  reference-perturbation, OmniEmbed, E5, and ImageBind evidence workflow.
- `scripts/run_omnicvr_reference_diagnostics.sh`: cross-benchmark
  reference diagnostic.

Launchers use atomic item caches and preserve completed work on resume. Replace
all `/path/to/...` placeholders. When running the extracted anonymous archive
rather than a Git checkout, pass `--expected-head SKIP` where that option is
present.

## 6. Rebuilding reported tables

The final per-query inputs and paired statistical outputs are under
`evidence/final/`. `verify_package.py` independently recomputes the key
human-valid sensitivity numbers and validates the final audits. No raw media is
needed for these checks.
