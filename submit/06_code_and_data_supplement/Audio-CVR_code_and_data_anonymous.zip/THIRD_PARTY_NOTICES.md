# Third-Party Notices

This review archive includes only one vendored third-party source component:
the pinned ImageBind inference runtime under
`third_party/imagebind_5120b6bb/`. Its license and upstream provenance are
preserved in that directory.

E5-Omni, Qwen2.5-Omni, OmniEmbed-MultiVENT, and the ImageBind-Huge weights are
not redistributed. Reviewers must obtain them under their respective model
terms.

Raw source videos are not redistributed. They remain subject to the terms of
their upstream datasets.

